package com.example.skincare.controller;


import com.example.skincare.views.LoginActivity;

public class LoginController {
    private final LoginActivity view;

    public LoginController(LoginActivity view) {
        this.view = view;
    }



    }

}
