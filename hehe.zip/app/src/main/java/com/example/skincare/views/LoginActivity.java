package com.example.skincare.views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.skincare.R;
import com.example.skincare.controller.LoginController;
import com.google.android.material.snackbar.Snackbar;


public class LoginActivity extends AppCompatActivity {

    public EditText email,password;
    public Button btnLogin;
    public TextView register;

    LoginController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);


        btnLogin = findViewById(R.id.btLogin);
        register = findViewById(R.id.Register);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        btnLogin.setOnClickListener(v->{
            controller.validateFields();
            Intent intent = new Intent(LoginActivity.this, HomePageActivity.class);
            startActivity(intent);
        });
        register.setOnClickListener(v->{
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });


    }
}